#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <numeric>
#include <algorithm>
#include <random>
#include <ctime>
#include <cstdlib>
#include <fstream>
#include <sstream>

using std::accumulate;
using std::string;
using std::vector;
using std::cout;
using std::cin;
using std::endl;
using std::sort;
using std::left;
using std::right;
using std::setw;
using std::setprecision;
using std::fixed;
using std::srand;
using std::time;
using std::rand;


