## Repo orientation (big picture)

- Small single-binary C++ program that models students (`Person`), reads user input, computes final grades and prints a table. Key sources:
  - `main.cpp` — program entry, reads N students into `vector<Person>` and prints results.
  - `Person.h` / `Person.cpp` — data model and grade calculation (average or median).
  - `Lib.h` — central header that pulls common std headers and `using` declarations used across the code.
  - `Task 1.cbp` + `bin/Debug/`, `obj/Debug/` — indicates the project was created with Code::Blocks and debug binary output is under `bin/Debug`.

## Critical patterns & conventions (project-specific)

- Centralized imports: `Lib.h` contains #includes and `using` declarations (e.g. `using std::vector`, `using std::string`). Files include `Lib.h` (or `Person.h`) instead of repeating headers.
- Public POD-style model: `Person` exposes public fields (firstname, surname, Homework, exam, Finalgrade) and relies on friend `operator<<`/`operator>>` for I/O.
- Two calculation strategies are implemented:
  - `Person::FinalAv()` — average of homework * 0.4 + exam * 0.6 (uses `std::accumulate`).
  - `Person::FinalMed()` — median of homework * 0.4 + exam * 0.6 (uses a local sorted copy in `med()`).
- I/O approach: interactive console input via `operator>>` (see `Person.cpp`). The `operator>>` currently requests a sequence of homework grades terminated by 'N' — note: the homework-read loop in `Person.cpp` contains an incomplete/garbled section (look for the stray token `Sti` and `while`) that needs attention before relying on it.

## Build & run (developer workflows)

- Primary hint: project has a Code::Blocks project file (`Task 1.cbp`) and Debug output folders — opening the `.cbp` in Code::Blocks will restore original build/run configuration.
- Quick terminal build (useful if you don't open Code::Blocks): compile with a standard g++ toolchain. From repository root (Windows PowerShell example):

```powershell
g++ -std=c++11 -O0 -g main.cpp Person.cpp -o bin/Debug/Task1.exe
.
\bin\Debug\Task1.exe
```

Adjust include paths if you move files; the code uses only standard library headers so there are no external deps.

## Files to inspect when changing behavior

- `Person.cpp` — change Final grade logic, the input parsing, copy/assignment/destructor behavior, and `operator>>`/`operator<<` formats.
- `Person.h` — data layout and public API for the model.
- `Lib.h` — global using/imports; editing it affects all translation units.

## Typical edits an AI agent might be asked to make

- Fix input parsing in `operator>>` in `Person.cpp` (complete the homework-reading loop and handle empty homework vector safely).
- Add validation: clamp homework/exam grades to expected ranges or fail gracefully on bad input.
- Replace global `using` declarations in `Lib.h` with qualified names for library hygiene — be aware this is a repo-wide change.
- Add unit-testable functions: extract parsing and grade-calculation logic so they can be tested without interactive stdin.

## Integration & risks

- No external libraries found; project depends only on the C++ standard library.
- The program is interactive — automated tests require refactoring I/O out of `operator>>` or providing stdin redirection.
- Watch for the incomplete code fragment in `Person.cpp` near the homework input: modifying `operator>>` is necessary before adding automated parsing tests.

## Quick pointers for the next iteration

- If you want me to: I can (A) fix the homework input loop in `Person.cpp` and add a small non-interactive test harness, or (B) generate a minimal README with build/run instructions and an example input file. Tell me which and I'll proceed.
